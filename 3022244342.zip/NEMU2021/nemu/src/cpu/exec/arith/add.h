#ifndef _ADD_H_
#define _ADD_H_

make_helper(add_i2a_v);
make_helper(add_i2rm_v);
make_helper(add_si2rm_v);
make_helper(add_r2rm_v);
make_helper(add_rm2r_v);

#endif