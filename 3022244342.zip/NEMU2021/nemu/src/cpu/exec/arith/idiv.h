#ifndef __IDIV_H__
#define __IDIV_H__

make_helper(idiv_rm_b);

make_helper(idiv_rm_v);

#endif
