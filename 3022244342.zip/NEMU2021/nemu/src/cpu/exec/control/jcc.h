#ifndef _JCC_H_
#define _JCC_H_

make_helper(jb_b);
make_helper(jne_b);
make_helper(jbe_b);
make_helper(ja_b);
make_helper(js_b);
make_helper(jns_b);
make_helper(jl_b);
make_helper(jge_b);
make_helper(jle_b);
make_helper(jg_b);

make_helper(jne_l);
make_helper(jbe_l);
make_helper(ja_l);
make_helper(jl_l);
make_helper(jge_l);
make_helper(jle_l);

#endif