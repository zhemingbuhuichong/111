#ifndef _JE_H_
#define _JE_H_

make_helper(je_i_b);
make_helper(je_i_v);

#endif