#ifndef _LEAVE_H_
#define _LEAVE_H_

make_helper(leave);

#endif