#ifndef _TEST_H_
#define _TEST_H_

make_helper(test_i2rm_b);
make_helper(test_r2rm_b);

make_helper(test_i2rm_v);
make_helper(test_r2rm_v);

#endif