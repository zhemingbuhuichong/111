#ifndef _SETCC_H_
#define _SETCC_H_

make_helper(setne);

#endif