#ifndef _LODS_H_
#define _LODS_H_

make_helper(lods_b);

make_helper(lods_v);

#endif