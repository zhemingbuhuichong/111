#ifndef __SCAS_H__
#define __SCAS_H__

make_helper(scas_b);

make_helper(scas_v);

#endif
